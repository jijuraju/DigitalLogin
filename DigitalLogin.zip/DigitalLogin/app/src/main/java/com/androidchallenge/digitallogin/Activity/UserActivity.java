package com.androidchallenge.digitallogin.Activity;

import android.os.Bundle;
import android.widget.TextView;

import com.androidchallenge.digitallogin.R;

/**
 * Created by DELL on 20-04-2019.
 */

public class UserActivity extends BaseActivity{

    private TextView txtView_name;
    private TextView txtView_user_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);
        bindConrols();
        setToolbar();
        String emailFromIntent = getIntent().getStringExtra("NAME");
        txtView_user_name.setText("Welcome "+emailFromIntent);
    }

    private void bindConrols() {
        txtView_name = (TextView) findViewById(R.id.txtView_name);
        txtView_user_name = (TextView) findViewById(R.id.txtView_user_name);
    }

    private void setToolbar() {
        txtView_name.setText(R.string.User);
    }
}
