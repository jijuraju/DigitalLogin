package com.androidchallenge.digitallogin.Activity;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by DELL on 20-04-2019.
 */

public class BaseActivity extends AppCompatActivity {
}
