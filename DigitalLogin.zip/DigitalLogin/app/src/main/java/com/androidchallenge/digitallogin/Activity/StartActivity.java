package com.androidchallenge.digitallogin.Activity;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.androidchallenge.digitallogin.R;

public class StartActivity extends BaseActivity implements View.OnClickListener{

    private Activity thisActivity = StartActivity.this;
    private TextView txtView_name;
    private Button btn_login;
    private Button btn_register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
        bindConrols();
        setToolbar();
    }

    private void bindConrols() {
        txtView_name = (TextView) findViewById(R.id.txtView_name);
        btn_login = (Button) findViewById(R.id.btn_login);
        btn_register = (Button) findViewById(R.id.btn_register);

        btn_login.setOnClickListener(this);
        btn_register.setOnClickListener(this);
    }

    //method to handle toolbar
    private void setToolbar() {
        txtView_name.setText(R.string.app_name);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {

            case R.id.btn_login:
                Intent login_intent = new Intent(thisActivity, LoginActivity.class);
                startActivity(login_intent);
                thisActivity.overridePendingTransition(R.anim.enter_from_right, R.anim.exit_to_left);
                break;

            case R.id.btn_register:
                Intent register_intent = new Intent(thisActivity, RegisterActivity.class);
                startActivity(register_intent);
                thisActivity.overridePendingTransition(R.anim.enter_from_right, R.anim.exit_to_left);
                break;
        }

    }
}
